#ifndef BOX_INFO_HPP
#define BOX_INFO_HPP

#include "robot_measurement.hpp"
#include "box_pose.hpp"

// BoxPose::BoxPose(PoseImgMeasurements const &measurements) {

// }


#endif //!BOX_INFO_HPP

#include <string>

#include <boost/optional.hpp>
#include <yaml-cpp/yaml.h>

#include "app_log.hpp"
#include "convert_3d.hpp"
#include "hog_detector.hpp"
#include "img_utilities.hpp"

RobotPose toRobotPose(YAML::Node const &n) {
  RobotPose robot_pose;
  robot_pose.x = n[0].as<double>();
  robot_pose.y = n[1].as<double>();
  robot_pose.z = n[2].as<double>();
  robot_pose.rx = n[3].as<double>();
  robot_pose.ry = n[4].as<double>();
  robot_pose.rz = n[5].as<double>();
  INFO("toRobotPose: ok");
  return robot_pose;
}

// data_dir : dir with files and config
// robot_data_fname : config filename in data_dir
RobotData readRobotData(std::string const &data_dir, std::string const &robot_data_fname) {
  RobotData robot_data;
  auto robot_data_node = YAML::LoadFile(data_dir + robot_data_fname);
  auto common_node = robot_data_node["common"];
  INFO("get common_node: ok");
  auto robot_on_object_pose_node = common_node["robot_on_object_pose"];
  INFO("get robot_on_object_pose_node: ok");
  auto camera_f = common_node["camera_f"];
  INFO("get camera_f: ok");
  auto camera_offset_z = common_node["camera_offset_z"];
  INFO("get camera_offset_z: ok");
  auto list_node = robot_data_node["list"];
  INFO("get list_node: ok");

  RobotData::Common common;
  common.robot_on_object_pose = toRobotPose(robot_on_object_pose_node);
  common.camera_f = camera_f.as<double>();
  INFO("get camera_f: ok");
  common.camera_offset_z = camera_offset_z.as<double>();
  INFO("get camera_offset_z: ok");
  robot_data.common = common;

  RobotData::List list;
  std::transform(list_node.begin(), list_node.end(), std::back_inserter(list),
                 [&data_dir](YAML::Node const &element_node) {
                   RobotData::ListElement element;
                   element.robot_pose = toRobotPose(element_node["robot_pose"]);
                   element.camera_img_fname =
                       data_dir + element_node["camera_img_fname"].as<std::string>();
                   return element;
                 });
  robot_data.list = list;
  return robot_data;
}

YAML::Node toYAML(RobotData const &robot_data) {
  YAML::Node main;

  {
    YAML::Node common;
    auto rp = robot_data.common.robot_on_object_pose;
    common["robot_on_object_pose"] =
        std::vector<double>{rp.x, rp.y, rp.z, rp.rx, rp.ry, rp.rz};
    common["camera_f"] = robot_data.common.camera_f;
    common["camera_offset_z"] = robot_data.common.camera_offset_z;
    common["distance_sonar"] = robot_data.common.distance;
    main["common"] = common;
  }

  YAML::Node list;
  for (auto elem : robot_data.list) {
    YAML::Node elem_n;
    auto rp = *elem.robot_pose;
    elem_n["robot_pose"] =
        std::vector<double>{rp.x, rp.y, rp.z, rp.rx, rp.ry, rp.rz};
    elem_n["camera_img_fname"] = elem.camera_img_fname;
    elem_n["distance_sonar"] = elem.distance;
    list.push_back(elem_n);
  }
  main["list"] = list;
  return main;
}

void create_hog_data() {
  std::string input_dir {"outputs/raw_data/"};
  std::string output_dir {"outputs/hog_data/"};
  RobotData robot_data = readRobotData(input_dir, "robot_data.yaml");
  int idx = 0;
  HOGDetectorLogger l(output_dir, &idx);
  HOGDetector d(l);
  auto &list = robot_data.list;
  for (auto &item : list) {
    if (idx % 20 == 0)
      INFO("idx: ", idx, "/", list.size());
    cv::Mat img = cv::imread(item.camera_img_fname);
    auto boxes = d.detect_boxes(img, 0.5);
    auto target_box_idx = std::distance(
        boxes.begin(), std::max_element(boxes.begin(), boxes.end(), area_cmp));
    l.add_img_pose_info(robot_data.common, item, target_box_idx,
                        boxes[target_box_idx]);
    ++idx;
  }
  INFO("done");
  l.dump_info();
}

// from file img_list.yaml read list [fname]
// [fname1, fname2, ...]
void show_bounding_boxes() {
  auto fnames = YAML::LoadFile("img_list.yaml");
  int idx = 0;
  HOGDetectorLogger l("output", &idx);
  HOGDetector d(l);
  for (auto const &fname : fnames) {
    INFO("fname ", fname);
    auto img = cv::imread(fname.as<std::string>());
    auto boxes = d.detect_boxes(img, 0.5);
    ++idx;
  }
  INFO("end");
}